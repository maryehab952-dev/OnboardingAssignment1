package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import com.example.myapplication.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity
        implements Fragment2.OnContinueListener,
        Fragment3.OnConfirmationListener {

    private ActivityMainBinding binding;

    private int currentFragment = 1;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        // Create Fragment1
        Fragment1 fragment1 = Fragment1.newInstance(null, null);

        // Show Fragment1
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragment_container, fragment1)
                .commit();

        // Activity Continue button
        binding.buttonContinue.setOnClickListener(view -> {

            if (currentFragment == 1) {

                // Move from Fragment1 to Fragment2
                Fragment2 fragment2 = Fragment2.newInstance(null, null);

                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, fragment2)
                        .addToBackStack(null)
                        .commit();

                currentFragment = 2;

                // Hide Activity button
                binding.buttonContinue.setVisibility(
                        android.view.View.GONE
                );
            }
        });
    }

    // Receive name from Fragment2
    @Override
    public void onContinue(String name) {

        this.name = name;

        // Create Fragment3 and send name
        Fragment3 fragment3 = Fragment3.newInstance(name);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment3)
                .addToBackStack(null)
                .commit();

        currentFragment = 3;
    }

    // Receive checkbox state from Fragment3
    @Override
    public void onConfirmationChanged(boolean isChecked) {

        Fragment fragment =
                getSupportFragmentManager()
                        .findFragmentById(R.id.fragment_container);

        if (fragment instanceof Fragment3) {

            ((Fragment3) fragment)
                    .updateConfirmation(isChecked);
        }
    }
}