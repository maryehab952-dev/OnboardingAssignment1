package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Fragment3 extends Fragment {

    TextView tvName;
    CheckBox cbConfirm;
    Button btnFinish;

    OnConfirmationListener listener;

    public interface OnConfirmationListener {
        void onConfirmationChanged(boolean isChecked);
    }

    public Fragment3() {
        // Required empty public constructor
    }

    public static Fragment3 newInstance(String name) {

        Fragment3 fragment = new Fragment3();

        Bundle args = new Bundle();

        args.putString("user_name", name);

        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {

        super.onAttach(context);

        if (context instanceof OnConfirmationListener) {

            listener = (OnConfirmationListener) context;

        } else {

            throw new RuntimeException(
                    context.toString()
                            + " must implement OnConfirmationListener"
            );
        }
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {

        View view = inflater.inflate(
                R.layout.fragment_3,
                container,
                false
        );

        tvName = view.findViewById(R.id.tvName);
        cbConfirm = view.findViewById(R.id.cbConfirm);
        btnFinish = view.findViewById(R.id.btnFinish);

        // Get name from Bundle
        Bundle args = getArguments();

        if (args != null) {

            String name = args.getString("user_name");

            tvName.setText("Welcome, " + name);
        }

        // Button is disabled initially
        btnFinish.setEnabled(false);

        btnFinish.setText("Continue");

        // Checkbox listener
        cbConfirm.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {

                    if (listener != null) {

                        listener.onConfirmationChanged(isChecked);
                    }
                }
        );

        return view;
    }

    // Update button according to checkbox state
    public void updateConfirmation(boolean isChecked) {

        btnFinish.setEnabled(isChecked);

        if (isChecked) {

            btnFinish.setText("Finish");

        } else {

            btnFinish.setText("Continue");
        }
    }

    @Override
    public void onDetach() {

        super.onDetach();

        listener = null;
    }
}