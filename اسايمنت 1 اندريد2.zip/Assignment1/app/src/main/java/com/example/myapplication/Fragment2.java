package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.databinding.Fragment2Binding;

public class Fragment2 extends Fragment {

    public static Fragment2Binding fragment2Binding;

    // Interface for communication with Host Activity
    public interface OnContinueListener {
        void onContinue(String name);
    }

    private OnContinueListener listener;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public Fragment2() {
        // Required empty public constructor
    }

    public static Fragment2 newInstance(String param1, String param2) {

        Fragment2 fragment = new Fragment2();

        Bundle args = new Bundle();

        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);

        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if (context instanceof OnContinueListener) {
            listener = (OnContinueListener) context;
        } else {
            throw new RuntimeException(
                    context.toString()
                            + " must implement OnContinueListener"
            );
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {

        fragment2Binding = Fragment2Binding.inflate(
                inflater,
                container,
                false
        );

        // Continue button
        fragment2Binding.buttonContinue.setOnClickListener(v -> {

            // Get name
            String name = fragment2Binding.editText
                    .getText()
                    .toString()
                    .trim();

            // Check if name is empty
            if (name.isEmpty()) {

                fragment2Binding.editText.setError(
                        "Please enter your name"
                );

                return;
            }

            // Get email
            String email = fragment2Binding.editEmail
                    .getText()
                    .toString()
                    .trim();

            // Get selected gender
            int selectedGenderId =
                    fragment2Binding.radioGroupGender
                            .getCheckedRadioButtonId();

            String gender = "";

            if (selectedGenderId != -1) {

                RadioButton selectedRadioButton =
                        fragment2Binding.getRoot()
                                .findViewById(selectedGenderId);

                gender = selectedRadioButton.getText().toString();
            }

            // Send name to Host Activity
            if (listener != null) {
                listener.onContinue(name);
            }

        });

        return fragment2Binding.getRoot();
    }

    @Override
    public void onDetach() {
        super.onDetach();

        listener = null;
    }
}